#!/bin/sh

disablepicom() {
    if [ -n "$(pgrep overlay)" ] || [ -n "$(pgrep SC2)" ] ; then
        echo "*****STEAM OVERLAY IS RUNNING*****"
        if [ -n "$(pgrep picom)" ]; then
            echo "*****PICOM IS RUNNING*****"
            $HOME/.config/bspwm/scripts/close-bar.sh
            killall picom
         fi
    else
        echo "*****STEAM OVERLAY IS NOT RUNNING*****"
        $HOME/.config/bspwm/scripts/open-bar.sh
        picom -b --experimental-backends &
    fi
}

while true ; do disablepicom ; sleep 5 ; done
