#!/bin/sh

if ! [[ -z $(xrandr | grep HDMI-A-0) ]]; then
    echo "HDMI-A-0 found"

    echo "Opening bar"
    eww open bar
else
    echo "HDMI-A-0 not found"

    echo "Opening sbar"
    eww open sbar
fi
