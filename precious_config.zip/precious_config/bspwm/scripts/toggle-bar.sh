#!/bin/bash

if ! [[ -z $(xrandr | grep HDMI-A-0) ]]; then
    echo "HDMI-A-0 found"
    if [[ $(eww windows | grep '*bar') ]]; then
        echo "Closing bar"
        eww close bar
    else
        echo "Opening bar"
        eww open bar
    fi
else
    echo "HDMI-A-0 now found"
    if [[ $(eww windows | grep '*bar1') ]]; then
        echo "Closing sbar"
         eww close sbar
    else
        echo "Opening sbar"
        eww open sbar
    fi
fi
