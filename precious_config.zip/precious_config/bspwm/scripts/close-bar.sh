#!/bin/sh

if ! [[ -z $(xrandr | grep HDMI-A-0) ]]; then
    echo "HDMI-A-0 found"

    echo "Closing bar"
    eww close bar
else
    echo "HDMI-A-0 not found"

    echo "Closing sbar"
    eww close sbar
fi
