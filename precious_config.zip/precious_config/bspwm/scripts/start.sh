#!/usr/bin/bash

xrandr --output HDMI-A-0 --mode 2560x1440 --rate 143.97 --primary
sleep 1
eww daemon
eww open bar
eww open sbar
dunst &
feh --bg-fill $HOME/Pictures/Wallpapers/shacks.png
pgrep -x sxhkd > /dev/null || sxhkd &
# picom --experimental-backends &
[ -z pgrep Discord ] && discord &
# $HOME/.config/bspwm/scripts/disable-picom-when-gaming.sh &
/usr/lib/polkit-gnome/polkit-gnome-authentication-agent-1 &
